import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { CATEGORIES, supabase } from '../lib/supabase';

const FALLBACK_IMAGES: Record<string, string> = {
  shoes: 'https://images.pexels.com/photos/2589653/pexels-photo-2589653.jpeg?auto=compress&cs=tinysrgb&w=1200',
  tshirts: 'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=1200',
  pants: 'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=1200',
  other: 'https://images.pexels.com/photos/1152079/pexels-photo-1152079.jpeg?auto=compress&cs=tinysrgb&w=1200',
};

export default function Collections() {
  const [sectionImages, setSectionImages] = useState<Record<string, string>>({});

  useEffect(() => {
    supabase
      .from('section_images')
      .select('category, image_url')
      .then(({ data }) => {
        if (data) {
          const map: Record<string, string> = {};
          data.forEach((img) => {
            if (!map[img.category]) map[img.category] = img.image_url;
          });
          setSectionImages(map);
        }
      });
  }, []);

  return (
    <div>
      <section className="border-b border-white/10 bg-[#07090c] py-16">
        <div className="site-shell">
          <p className="gold-label mb-3">Explore</p>
          <h1 className="mb-4 font-serif text-5xl text-white">Collections</h1>
          <p className="max-w-2xl leading-relaxed text-stone-400">
            Explore our thoughtfully curated categories, each offering a distinct expression of elegance.
          </p>
        </div>
      </section>

      <section className="py-14">
        <div className="site-shell grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {CATEGORIES.map((cat, idx) => {
            const img = sectionImages[cat.key] ?? FALLBACK_IMAGES[cat.key];
            return (
              <Link
                key={cat.key}
                to={`/collections/${cat.key}`}
                className="group relative block h-[320px] overflow-hidden border border-white/10 bg-black"
              >
                <div
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                  style={{ backgroundImage: `url('${img}')` }}
                />
                <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(4,5,7,0.08)_0%,rgba(4,5,7,0.35)_40%,rgba(4,5,7,0.92)_100%)]" />
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <p className="mb-2 text-[11px] uppercase tracking-[0.28em] text-amber-300">
                    0{idx + 1}
                  </p>
                  <h2 className="mb-2 font-serif text-3xl text-white">{cat.label}</h2>
                  <p className="mb-4 line-clamp-2 text-sm text-stone-300">{cat.description}</p>
                  <span className="inline-flex items-center gap-2 border border-amber-500/60 bg-amber-500/10 px-4 py-2 text-[11px] uppercase tracking-[0.22em] text-amber-100 transition-all group-hover:border-amber-400 group-hover:bg-amber-400 group-hover:text-stone-950">
                    Discover <ArrowRight size={14} />
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>
    </div>
  );
}
