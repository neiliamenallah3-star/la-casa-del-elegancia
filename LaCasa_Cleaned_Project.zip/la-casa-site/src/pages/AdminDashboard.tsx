import { useEffect, useRef, useState } from 'react';
import { Navigate } from 'react-router-dom';
import {
  ChevronDown,
  ChevronUp,
  Image as ImageIcon,
  LogOut,
  Plus,
  Settings,
  Smartphone,
  Trash2,
  Upload,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import {
  CATEGORIES,
  Category,
  Product,
  SectionImage,
  getStoragePathFromUrl,
  removeStoreImage,
  saveStoreImage,
  supabase,
} from '../lib/supabase';

const MAX_IMAGE_SIZE_MB = 5;

const revokePreview = (previewUrl: string | null) => {
  if (previewUrl?.startsWith('blob:')) {
    URL.revokeObjectURL(previewUrl);
  }
};

const validateImageFile = (file: File) => {
  if (!file.type.startsWith('image/')) {
    return 'Please choose an image file.';
  }

  if (file.size > MAX_IMAGE_SIZE_MB * 1024 * 1024) {
    return `Image must be ${MAX_IMAGE_SIZE_MB}MB or smaller.`;
  }

  return null;
};

export default function AdminDashboard() {
  const { session, signOut } = useAuth();
  const [activeCategory, setActiveCategory] = useState<Category>('shoes');
  const [products, setProducts] = useState<Product[]>([]);
  const [sectionImages, setSectionImages] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [productImageFile, setProductImageFile] = useState<File | null>(null);
  const [productImagePreview, setProductImagePreview] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const [sectionImgUrl, setSectionImgUrl] = useState('');
  const [sectionImageFile, setSectionImageFile] = useState<File | null>(null);
  const [sectionImagePreview, setSectionImagePreview] = useState<string | null>(null);

  const [showSettings, setShowSettings] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [accountMsg, setAccountMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [savingAccount, setSavingAccount] = useState(false);

  const productImageInputRef = useRef<HTMLInputElement | null>(null);
  const sectionImageInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    return () => {
      revokePreview(productImagePreview);
      revokePreview(sectionImagePreview);
    };
  }, [productImagePreview, sectionImagePreview]);

  useEffect(() => {
    loadProducts();
    loadSectionImages();
  }, [activeCategory]);

  if (!session) return <Navigate to="/admin" replace />;

  const resetProductImageSelection = () => {
    revokePreview(productImagePreview);
    setProductImageFile(null);
    setProductImagePreview(null);
    if (productImageInputRef.current) {
      productImageInputRef.current.value = '';
    }
  };

  const resetSectionImageSelection = () => {
    revokePreview(sectionImagePreview);
    setSectionImageFile(null);
    setSectionImagePreview(null);
    if (sectionImageInputRef.current) {
      sectionImageInputRef.current.value = '';
    }
  };

  const loadProducts = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('products')
      .select('*')
      .eq('category', activeCategory)
      .order('created_at', { ascending: false });
    setProducts((data as Product[]) ?? []);
    setLoading(false);
  };

  const loadSectionImages = async () => {
    const { data } = await supabase.from('section_images').select('*');
    if (data) {
      const map: Record<string, string> = {};
      (data as SectionImage[]).forEach((img) => {
        if (!map[img.category]) map[img.category] = img.image_url;
      });
      setSectionImages(map);
    }
  };

  const handleProductFileChange = (file: File | null) => {
    if (!file) return;

    const error = validateImageFile(file);
    if (error) {
      setMsg({ text: error, type: 'error' });
      return;
    }

    revokePreview(productImagePreview);
    setProductImageFile(file);
    setProductImagePreview(URL.createObjectURL(file));
    setMsg(null);
  };

  const handleSectionFileChange = (file: File | null) => {
    if (!file) return;

    const error = validateImageFile(file);
    if (error) {
      setMsg({ text: error, type: 'error' });
      return;
    }

    revokePreview(sectionImagePreview);
    setSectionImageFile(file);
    setSectionImagePreview(URL.createObjectURL(file));
    setMsg(null);
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    let uploadedImageUrl: string | null = null;

    try {
      setSaving(true);
      setMsg(null);

      const finalImageUrl = productImageFile
        ? ((uploadedImageUrl = await saveStoreImage(productImageFile, 'products')), uploadedImageUrl)
        : imageUrl.trim() || null;

      const { error } = await supabase.from('products').insert({
        category: activeCategory,
        title: title.trim(),
        description: description.trim() || null,
        price: price.trim() || null,
        image_url: finalImageUrl,
      });

      if (error) {
        if (uploadedImageUrl) {
          await removeStoreImage(uploadedImageUrl);
        }
        setMsg({ text: `Error: ${error.message}`, type: 'error' });
        return;
      }

      setTitle('');
      setDescription('');
      setPrice('');
      setImageUrl('');
      resetProductImageSelection();
      setMsg({ text: 'Product added successfully.', type: 'success' });
      await loadProducts();
    } catch (error) {
      if (uploadedImageUrl) {
        await removeStoreImage(uploadedImageUrl);
      }
      setMsg({
        text: error instanceof Error ? error.message : 'Unable to upload the image right now.',
        type: 'error',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteProduct = async (id: string, imagePath: string | null) => {
    if (!confirm('Delete this product?')) return;

    const { error } = await supabase.from('products').delete().eq('id', id);

    if (error) {
      setMsg({ text: `Error: ${error.message}`, type: 'error' });
      return;
    }

    if (imagePath && getStoragePathFromUrl(imagePath)) {
      await removeStoreImage(imagePath);
    }

    setMsg({ text: 'Product deleted.', type: 'success' });
    await loadProducts();
  };

  const handleSetSectionImage = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!sectionImageFile && !sectionImgUrl.trim()) {
      setMsg({ text: 'Choose a cover photo or paste an image URL.', type: 'error' });
      return;
    }

    const previousImageUrl = sectionImages[activeCategory] ?? null;
    let uploadedImageUrl: string | null = null;

    try {
      setSaving(true);
      setMsg(null);

      const finalImageUrl = sectionImageFile
        ? ((uploadedImageUrl = await saveStoreImage(sectionImageFile, 'sections')), uploadedImageUrl)
        : sectionImgUrl.trim();

      await supabase.from('section_images').delete().eq('category', activeCategory);
      const { error } = await supabase.from('section_images').insert({
        category: activeCategory,
        image_url: finalImageUrl,
      });

      if (error) {
        if (uploadedImageUrl) {
          await removeStoreImage(uploadedImageUrl);
        }
        setMsg({ text: `Error: ${error.message}`, type: 'error' });
        return;
      }

      if (previousImageUrl && getStoragePathFromUrl(previousImageUrl)) {
        await removeStoreImage(previousImageUrl);
      }

      setSectionImages((prev) => ({
        ...prev,
        [activeCategory]: finalImageUrl,
      }));
      setSectionImgUrl('');
      resetSectionImageSelection();
      setMsg({ text: 'Section cover image updated.', type: 'success' });
      await loadSectionImages();
    } catch (error) {
      if (uploadedImageUrl) {
        await removeStoreImage(uploadedImageUrl);
      }
      setMsg({
        text: error instanceof Error ? error.message : 'Unable to update the cover image right now.',
        type: 'error',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim()) return;
    setSavingAccount(true);
    setAccountMsg(null);
    const { error } = await supabase.auth.updateUser({ email: newEmail.trim() });
    setSavingAccount(false);
    if (error) {
      setAccountMsg({ text: error.message, type: 'error' });
    } else {
      setAccountMsg({ text: 'Email updated successfully. You may need to confirm the new address.', type: 'success' });
      setNewEmail('');
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      setAccountMsg({ text: 'Password must be at least 8 characters.', type: 'error' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setAccountMsg({ text: 'Passwords do not match.', type: 'error' });
      return;
    }
    setSavingAccount(true);
    setAccountMsg(null);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setSavingAccount(false);
    if (error) {
      setAccountMsg({ text: error.message, type: 'error' });
    } else {
      setAccountMsg({ text: 'Password updated successfully.', type: 'success' });
      setNewPassword('');
      setConfirmPassword('');
    }
  };

  const msgClass = (type: 'success' | 'error') =>
    type === 'success'
      ? 'bg-green-50 border border-green-300 text-green-800'
      : 'bg-red-50 border border-red-300 text-red-800';

  const activeCategoryLabel = CATEGORIES.find((c) => c.key === activeCategory)?.label;
  const visibleSectionPreview = sectionImagePreview || sectionImages[activeCategory] || null;

  return (
    <div className="min-h-screen bg-stone-50">
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12">
        <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-serif text-3xl text-stone-800">Owner Dashboard</h1>
            <p className="mt-1 text-sm text-stone-500">{session.user.email}</p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                setShowSettings(!showSettings);
                setAccountMsg(null);
              }}
              className="inline-flex items-center gap-2 text-sm uppercase tracking-widest text-stone-600 transition-colors hover:text-stone-900"
            >
              <Settings size={18} /> Account
              {showSettings ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </button>
            <button
              onClick={signOut}
              className="inline-flex items-center gap-2 text-sm uppercase tracking-widest text-stone-600 transition-colors hover:text-stone-900"
            >
              <LogOut size={18} /> Sign Out
            </button>
          </div>
        </div>

        <div className="mb-8 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-4 text-sm text-stone-700 sm:px-5">
          <div className="flex items-start gap-3">
            <Smartphone size={18} className="mt-0.5 shrink-0 text-amber-700" />
            <div>
              <p className="font-medium text-stone-800">Phone upload is ready.</p>
              <p className="mt-1 text-stone-600">
                The owner can open this dashboard on a phone, tap the photo picker, and use the camera or gallery.
              </p>
            </div>
          </div>
        </div>

        {showSettings && (
          <div className="mb-8 bg-white p-6 border border-stone-200">
            <h2 className="mb-6 flex items-center gap-2 font-serif text-xl text-stone-800">
              <Settings size={20} /> Account Settings
            </h2>

            {accountMsg && (
              <div className={`mb-5 px-4 py-3 text-sm ${msgClass(accountMsg.type)}`}>
                {accountMsg.text}
              </div>
            )}

            <div className="grid gap-8 md:grid-cols-2">
              <form onSubmit={handleUpdateEmail} className="flex flex-col gap-3">
                <h3 className="border-b border-stone-100 pb-2 text-sm font-medium uppercase tracking-widest text-stone-700">
                  Change Email
                </h3>
                <p className="text-xs text-stone-500">Current: {session.user.email}</p>
                <input
                  type="email"
                  required
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="New email address"
                  className="border border-stone-300 px-4 py-2 text-sm focus:border-amber-600 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={savingAccount}
                  className="self-start bg-stone-800 px-5 py-2 text-sm uppercase tracking-widest text-white transition-colors hover:bg-stone-900 disabled:opacity-50"
                >
                  {savingAccount ? 'Saving...' : 'Update Email'}
                </button>
              </form>

              <form onSubmit={handleUpdatePassword} className="flex flex-col gap-3">
                <h3 className="border-b border-stone-100 pb-2 text-sm font-medium uppercase tracking-widest text-stone-700">
                  Change Password
                </h3>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="New password (min. 8 chars)"
                  className="border border-stone-300 px-4 py-2 text-sm focus:border-amber-600 focus:outline-none"
                />
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm new password"
                  className="border border-stone-300 px-4 py-2 text-sm focus:border-amber-600 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={savingAccount}
                  className="self-start bg-stone-800 px-5 py-2 text-sm uppercase tracking-widest text-white transition-colors hover:bg-stone-900 disabled:opacity-50"
                >
                  {savingAccount ? 'Saving...' : 'Update Password'}
                </button>
              </form>
            </div>
          </div>
        )}

        {msg && (
          <div className={`mb-6 px-4 py-3 text-sm ${msgClass(msg.type)}`}>
            {msg.text}
          </div>
        )}

        <div className="mb-10 flex flex-wrap gap-2 border-b border-stone-200 pb-4">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setActiveCategory(cat.key)}
              className={`px-4 py-2 text-sm uppercase tracking-widest transition-colors sm:px-5 ${
                activeCategory === cat.key
                  ? 'bg-stone-900 text-amber-50'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="mb-8 bg-white p-6 border border-stone-200">
          <h2 className="mb-4 flex items-center gap-2 font-serif text-xl text-stone-800">
            <ImageIcon size={20} /> Section Cover Image
          </h2>
          <div className="flex flex-col gap-6 md:flex-row">
            <div className="h-48 w-full overflow-hidden bg-stone-100 md:w-64">
              {visibleSectionPreview ? (
                <img src={visibleSectionPreview} alt="cover preview" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-sm text-stone-400">
                  No cover set
                </div>
              )}
            </div>

            <form onSubmit={handleSetSectionImage} className="flex-1 space-y-4">
              <div>
                <label className="mb-1 block text-sm text-stone-600">
                  Upload a cover photo for the {activeCategoryLabel} section
                </label>
                <input
                  ref={sectionImageInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={(e) => handleSectionFileChange(e.target.files?.[0] ?? null)}
                  className="block w-full text-sm text-stone-600 file:mr-4 file:border-0 file:bg-stone-900 file:px-4 file:py-2 file:text-sm file:uppercase file:tracking-widest file:text-amber-50 hover:file:bg-stone-800"
                />
                <p className="mt-2 text-xs text-stone-500">
                  Works on phone camera or gallery. Max {MAX_IMAGE_SIZE_MB}MB. If cloud storage is not ready yet, the photo will still save.
                </p>
              </div>

              <div>
                <label className="mb-1 block text-sm text-stone-600">Or use an external image URL</label>
                <input
                  type="url"
                  value={sectionImgUrl}
                  onChange={(e) => setSectionImgUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full border border-stone-300 px-4 py-2 focus:border-amber-600 focus:outline-none"
                />
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 bg-stone-800 px-5 py-2 text-sm uppercase tracking-widest text-white transition-colors hover:bg-stone-900 disabled:opacity-50"
                >
                  <Upload size={16} /> {saving ? 'Saving...' : 'Update Cover'}
                </button>
                {(sectionImageFile || sectionImagePreview) && (
                  <button
                    type="button"
                    onClick={resetSectionImageSelection}
                    className="px-5 py-2 text-sm uppercase tracking-widest text-stone-600 transition-colors hover:text-stone-900"
                  >
                    Clear Photo
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>

        <div className="mb-8 bg-white p-6 border border-stone-200">
          <h2 className="mb-4 flex items-center gap-2 font-serif text-xl text-stone-800">
            <Plus size={20} /> Add New Product
          </h2>
          <form onSubmit={handleAddProduct} className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm text-stone-600">Title *</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full border border-stone-300 px-4 py-2 focus:border-amber-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm text-stone-600">Price</label>
              <input
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="e.g. 120 TND"
                className="w-full border border-stone-300 px-4 py-2 focus:border-amber-600 focus:outline-none"
              />
            </div>
            <div className="md:col-span-2">
              <label className="mb-1 block text-sm text-stone-600">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full border border-stone-300 px-4 py-2 focus:border-amber-600 focus:outline-none"
              />
            </div>

            <div className="md:col-span-2">
              <label className="mb-1 block text-sm text-stone-600">Product Photo</label>
              <input
                ref={productImageInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={(e) => handleProductFileChange(e.target.files?.[0] ?? null)}
                className="block w-full text-sm text-stone-600 file:mr-4 file:border-0 file:bg-amber-700 file:px-4 file:py-2 file:text-sm file:uppercase file:tracking-widest file:text-amber-50 hover:file:bg-amber-600"
              />
              <p className="mt-2 text-xs text-stone-500">
                Best for the owner on mobile: take a photo or choose one from the phone gallery.
              </p>
            </div>

            {(productImagePreview || imageUrl) && (
              <div className="md:col-span-2">
                <div className="h-56 w-full overflow-hidden rounded-lg bg-stone-100 sm:w-72">
                  <img
                    src={productImagePreview || imageUrl}
                    alt="product preview"
                    className="h-full w-full object-cover"
                  />
                </div>
              </div>
            )}

            <div className="md:col-span-2">
              <label className="mb-1 block text-sm text-stone-600">Or use an external image URL</label>
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://..."
                className="w-full border border-stone-300 px-4 py-2 focus:border-amber-600 focus:outline-none"
              />
            </div>

            <div className="md:col-span-2 flex flex-wrap gap-3">
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-2 bg-amber-700 px-6 py-2.5 text-sm uppercase tracking-widest text-amber-50 transition-colors hover:bg-amber-600 disabled:opacity-50"
              >
                <Plus size={16} /> {saving ? 'Saving...' : 'Add Product'}
              </button>
              {(productImageFile || productImagePreview) && (
                <button
                  type="button"
                  onClick={resetProductImageSelection}
                  className="px-5 py-2 text-sm uppercase tracking-widest text-stone-600 transition-colors hover:text-stone-900"
                >
                  Clear Photo
                </button>
              )}
            </div>
          </form>
        </div>

        <div>
          <h2 className="mb-4 font-serif text-xl text-stone-800">
            Products in {activeCategoryLabel} ({products.length})
          </h2>
          {loading ? (
            <p className="text-stone-500">Loading...</p>
          ) : products.length === 0 ? (
            <p className="text-sm text-stone-500">No products yet.</p>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {products.map((p) => (
                <div key={p.id} className="group border border-stone-200 bg-white">
                  <div className="aspect-[3/4] overflow-hidden bg-stone-100">
                    {p.image_url ? (
                      <img src={p.image_url} alt={p.title} className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-stone-400">
                        <ImageIcon size={32} />
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-serif text-lg text-stone-800">{p.title}</h3>
                    {p.price && <p className="mt-1 text-sm text-amber-800">{p.price}</p>}
                    {p.description && (
                      <p className="mt-2 text-xs text-stone-500 line-clamp-2">{p.description}</p>
                    )}
                    <button
                      onClick={() => handleDeleteProduct(p.id, p.image_url)}
                      className="mt-3 inline-flex items-center gap-1 text-xs uppercase tracking-widest text-red-600 transition-colors hover:text-red-800"
                    >
                      <Trash2 size={14} /> Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
