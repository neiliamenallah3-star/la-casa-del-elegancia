import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, PackageOpen } from 'lucide-react';
import { CATEGORIES, Product, supabase } from '../lib/supabase';

export default function SectionPage() {
  const { category } = useParams<{ category: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const cat = CATEGORIES.find((c) => c.key === category);

  useEffect(() => {
    if (!cat) return;
    setLoading(true);
    supabase
      .from('products')
      .select('*')
      .eq('category', cat.key)
      .order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (!error && data) setProducts(data as Product[]);
        setLoading(false);
      });
  }, [category]);

  if (!cat) {
    return (
      <div className="py-32 text-center">
        <p className="text-stone-600">Category not found.</p>
        <Link to="/collections" className="text-amber-700 hover:underline mt-4 inline-block">
          Back to Collections
        </Link>
      </div>
    );
  }

  return (
    <div>
      <section className="border-b border-white/10 bg-[#07090c] py-16">
        <div className="site-shell">
          <Link
            to="/collections"
            className="mb-6 inline-flex items-center gap-2 text-xs uppercase tracking-[0.26em] text-amber-300 transition-colors hover:text-amber-100"
          >
            <ArrowLeft size={16} /> Back to Collections
          </Link>
          <p className="gold-label mb-3">Category</p>
          <h1 className="mb-3 font-serif text-5xl text-white">{cat.label}</h1>
          <p className="max-w-xl leading-relaxed text-stone-400">{cat.description}</p>
        </div>
      </section>

      <section className="py-14">
        <div className="site-shell">
        {loading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-96 animate-pulse border border-white/10 bg-white/5" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="dark-panel py-24 text-center">
            <PackageOpen size={48} className="mx-auto mb-4 text-stone-500" />
            <p className="text-lg text-stone-300">No products in this collection yet.</p>
            <p className="mt-2 text-sm text-stone-500">Check back soon for new arrivals.</p>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {products.map((product) => (
              <div key={product.id} className="group overflow-hidden border border-white/10 bg-[#0b0d11] transition-colors hover:border-amber-500/40">
                <div className="aspect-[0.82] overflow-hidden bg-stone-900">
                  {product.image_url ? (
                    <img
                      src={product.image_url}
                      alt={product.title}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-stone-500">
                      <PackageOpen size={40} />
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <p className="mb-2 text-[11px] uppercase tracking-[0.28em] text-amber-400">La Casa</p>
                  <h3 className="mb-2 font-serif text-2xl text-white">{product.title}</h3>
                  {product.description && (
                    <p className="mb-3 text-sm leading-relaxed text-stone-400">{product.description}</p>
                  )}
                  {product.price && (
                    <p className="font-medium tracking-wide text-amber-300">{product.price}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
        </div>
      </section>
    </div>
  );
}
