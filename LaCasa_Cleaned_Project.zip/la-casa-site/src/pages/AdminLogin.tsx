import { useState } from 'react';
import { useNavigate, Navigate, Link } from 'react-router-dom';
import { Lock, Mail } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function AdminLogin() {
  const { session, signIn } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (session) return <Navigate to="/admin/dashboard" replace />;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    const { error } = await signIn(email, password);
    setSubmitting(false);
    if (error) {
      setError(error);
    } else {
      navigate('/admin/dashboard');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-6 py-16 bg-stone-900">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-amber-700/20 border border-amber-700/40 mb-6">
            <Lock size={28} className="text-amber-400" />
          </div>
          <h1 className="font-serif text-3xl text-amber-50 tracking-wider mb-2">Owner Access</h1>
          <p className="text-stone-400 text-sm">Private login for store management</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-amber-200 text-xs tracking-widest uppercase mb-2">Email</label>
            <div className="relative">
              <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-500" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-stone-800 border border-stone-700 text-amber-50 pl-12 pr-4 py-3 focus:outline-none focus:border-amber-600 transition-colors"
                placeholder="owner@example.com"
              />
            </div>
          </div>
          <div>
            <label className="block text-amber-200 text-xs tracking-widest uppercase mb-2">Password</label>
            <div className="relative">
              <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-500" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-stone-800 border border-stone-700 text-amber-50 pl-12 pr-4 py-3 focus:outline-none focus:border-amber-600 transition-colors"
                placeholder="••••••••"
              />
            </div>
          </div>

          {error && (
            <p className="text-red-400 text-sm bg-red-900/20 border border-red-800/40 px-4 py-3">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-amber-700 hover:bg-amber-600 disabled:opacity-50 text-amber-50 py-3 text-sm tracking-widest uppercase transition-colors"
          >
            {submitting ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        <p className="text-center text-stone-500 text-sm mt-6">
          First time?{' '}
          <Link to="/admin/setup" className="text-amber-400 hover:text-amber-300 transition-colors">
            Create your owner account
          </Link>
        </p>
      </div>
    </div>
  );
}
