import { Link } from 'react-router-dom';
import { ArrowRight, CreditCard, ShieldCheck, Sparkles, Truck } from 'lucide-react';
import heroStorefront from '../assets/hero-storefront.jpg';

export default function Home() {
  return (
    <div>
      <section className="relative overflow-hidden border-b border-white/10">
        <img
          src={heroStorefront}
          alt="La Casa storefront"
          className="absolute inset-0 h-full w-full object-cover object-[72%_34%] md:object-[center_30%]"
        />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,8,10,0.22)_0%,rgba(6,8,10,0.1)_32%,rgba(6,8,10,0.72)_100%)] md:bg-[linear-gradient(90deg,rgba(6,8,10,0.78)_0%,rgba(6,8,10,0.44)_38%,rgba(6,8,10,0.16)_100%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,8,10,0.12)_0%,rgba(6,8,10,0.02)_28%,rgba(6,8,10,0.7)_100%)] md:bg-[linear-gradient(180deg,rgba(6,8,10,0.32)_0%,rgba(6,8,10,0.04)_35%,rgba(6,8,10,0.62)_100%)]" />

        <div className="site-shell relative flex min-h-[620px] items-end py-12 md:min-h-[700px] md:items-center md:py-16">
          <div className="max-w-xl pb-4 md:pb-0">
            <p className="gold-label mb-4 animate-fade-in">Style • Quality • Elegance</p>
            <h1 className="mb-5 font-serif text-4xl leading-[0.9] text-white sm:text-6xl md:text-7xl">
              Elegance for
              <br />
              everyday life
            </h1>
            <p className="mb-8 max-w-lg text-sm leading-relaxed text-stone-200 sm:text-base md:text-lg">
              Discover our new collections, designed to reveal your personality with
              refined fashion and timeless style.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link to="/collections" className="gold-button">
                Explore our collection
                <ArrowRight size={16} />
              </Link>
              <Link to="/store" className="ghost-button">
                Visit the store
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="border-b border-white/10 bg-[#07090c]">
        <div className="site-shell grid gap-5 py-5 md:grid-cols-4">
          {[
            { icon: Truck, title: 'Fast Delivery', text: '48h partout en Tunisie' },
            { icon: Sparkles, title: 'Premium Products', text: 'Quality guarantee' },
            { icon: CreditCard, title: 'Secure Payment', text: '100% secured' },
            { icon: ShieldCheck, title: 'Satisfied or refunded', text: 'Return sous 7 jours' },
          ].map((item) => (
            <div key={item.title} className="flex items-start gap-3 border border-white/10 bg-white/[0.02] px-4 py-4">
              <item.icon size={18} className="mt-0.5 text-amber-400" />
              <div>
                <p className="text-[11px] uppercase tracking-[0.22em] text-amber-200">{item.title}</p>
                <p className="mt-1 text-xs text-stone-400">{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-[#050608] py-16">
        <div className="site-shell">
          <div className="mb-7 flex items-end justify-between gap-4">
            <div>
              <p className="gold-label mb-2">Nos collections</p>
              <h2 className="font-serif text-3xl text-white sm:text-4xl">The Art of Elegance</h2>
            </div>
            <Link
              to="/collections"
              className="hidden text-xs uppercase tracking-[0.24em] text-amber-300 transition-colors hover:text-amber-100 sm:inline-flex"
            >
              View all collections
            </Link>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {[
              { title: 'Crafted Quality', text: 'Every piece selected for its craftsmanship and durability.' },
              { title: 'Timeless Style', text: 'Designs that remain elegant season after season.' },
              { title: 'Personal Service', text: 'Visit our store in Gabes for a personalized experience.' },
            ].map((item) => (
              <div key={item.title} className="dark-panel p-7">
                <p className="mb-3 text-[11px] uppercase tracking-[0.3em] text-amber-400">La Casa</p>
                <h3 className="mb-3 font-serif text-3xl text-white">{item.title}</h3>
                <p className="text-sm leading-relaxed text-stone-400">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
