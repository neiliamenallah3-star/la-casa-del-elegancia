import { MapPin, Navigation } from 'lucide-react';

const MAPS_URL = 'https://www.google.com/maps/search/?api=1&query=V3JR%2B8VH%20Avenue%20B%C3%A9chir%20El%20Jaziri%20Gabes%20Tunisia';

export default function Store() {
  return (
    <div>
      <section className="border-b border-white/10 bg-[#07090c] py-16">
        <div className="site-shell text-center">
          <p className="gold-label mb-3">Boutique</p>
          <h1 className="mb-4 font-serif text-5xl text-white">Store</h1>
          <p className="mx-auto max-w-2xl leading-relaxed text-stone-400">
            We invite you to experience La Casa del Elegancia in person.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="site-shell grid gap-8 lg:grid-cols-[0.95fr_1.05fr] lg:items-start">
          <div className="dark-panel p-8 text-center lg:text-left">
            <div className="mb-6 inline-flex h-16 w-16 items-center justify-center rounded-full border border-amber-500/30 bg-amber-500/10">
              <MapPin size={30} className="text-amber-400" />
            </div>
            <h2 className="mb-5 font-serif text-4xl text-white">Visit Us</h2>
            <p className="text-lg leading-relaxed text-stone-300 mb-2">
              Avenue Béchir El Jaziri
            </p>
            <p className="mb-8 text-lg leading-relaxed text-stone-300">
              Gabes, Tunisia
            </p>
            <p className="mb-8 max-w-xl leading-relaxed text-stone-400">
              Come explore our full collection in person. Our team is ready to help you find
              the perfect piece to elevate your wardrobe.
            </p>
            <a href={MAPS_URL} target="_blank" rel="noopener noreferrer" className="gold-button">
              <Navigation size={16} />
              Get Directions
            </a>
          </div>
          <div className="overflow-hidden border border-white/10 bg-black">
            <iframe
              title="Store location"
              width="100%"
              height="460"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              src="https://www.google.com/maps?q=V3JR%2B8VH%20Avenue%20B%C3%A9chir%20El%20Jaziri%20Gabes%20Tunisia&output=embed"
            />
          </div>
        </div>
      </section>
    </div>
  );
}
