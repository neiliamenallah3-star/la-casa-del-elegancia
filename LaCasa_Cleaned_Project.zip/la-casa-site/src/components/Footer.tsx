import { Instagram, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-[#040507] text-stone-400">
      <div className="site-shell grid gap-8 py-14 md:grid-cols-3">
        <div>
          <h3 className="mb-3 font-serif text-2xl lowercase tracking-tight text-white">la casa del elegancia</h3>
          <p className="max-w-sm text-sm leading-relaxed text-stone-400">
            Where elegance meets everyday style. Curated fashion for the discerning individual.
          </p>
        </div>
        <div>
          <h4 className="mb-3 text-xs uppercase tracking-[0.28em] text-amber-300">Visit Us</h4>
          <p className="text-sm leading-relaxed text-stone-300">
            Avenue Béchir El Jaziri<br />
            Gabes, Tunisia
          </p>
        </div>
        <div>
          <h4 className="mb-3 text-xs uppercase tracking-[0.28em] text-amber-300">Connect</h4>
          <a
            href="https://www.instagram.com/la.casa.del.elegancia"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm text-stone-300 transition-colors hover:text-amber-200"
          >
            <Instagram size={18} /> @la.casa.del.elegancia
          </a>
          <div className="mt-2 flex items-center gap-2 text-sm text-stone-400">
            <MapPin size={18} /> Gabes, Tunisia
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-stone-500">
        © {new Date().getFullYear()} La Casa del Elegancia. All rights reserved.
        <span className="mx-2">·</span>
        <a href="/admin" className="hover:text-amber-300 transition-colors">Owner Login</a>
      </div>
    </footer>
  );
}
