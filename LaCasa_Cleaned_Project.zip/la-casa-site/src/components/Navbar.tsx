import { Link, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { Menu, X } from 'lucide-react';

const links = [
  { to: '/', label: 'Home' },
  { to: '/collections', label: 'Collections' },
  { to: '/store', label: 'Store' },
];

export default function Navbar() {
  const location = useLocation();
  const [open, setOpen] = useState(false);

  const isActive = (path: string) =>
    path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#040507]/95 backdrop-blur-md">
      <nav className="site-shell flex min-h-[74px] items-center justify-between gap-4">
        <Link to="/" className="group shrink-0 leading-none">
          <span className="block font-serif text-[2rem] lowercase tracking-tight text-white transition-colors group-hover:text-amber-100">
            la casa
          </span>
          <span className="block text-[11px] lowercase tracking-[0.12em] text-stone-400">
            del elegancia
          </span>
        </Link>

        <div className="hidden items-center gap-7 md:flex">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`relative py-1 text-[11px] uppercase tracking-[0.26em] transition-colors ${
                isActive(link.to) ? 'text-amber-300' : 'text-stone-300 hover:text-amber-200'
              }`}
            >
              {link.label}
              {isActive(link.to) && (
                <span className="absolute -bottom-4 left-0 right-0 h-px bg-amber-500/80" />
              )}
            </Link>
          ))}
        </div>
        <button
          className="text-amber-100 md:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-white/10 bg-[#07080b] md:hidden">
          <div className="site-shell flex flex-col gap-4 py-5">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setOpen(false)}
                className={`text-sm uppercase tracking-[0.24em] ${
                  isActive(link.to) ? 'text-amber-200' : 'text-stone-300'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
