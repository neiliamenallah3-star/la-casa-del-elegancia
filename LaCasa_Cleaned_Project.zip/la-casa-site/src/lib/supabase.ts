import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
export const PRODUCT_IMAGES_BUCKET = 'product-images';

export type Category = 'shoes' | 'tshirts' | 'pants' | 'other';

export interface Product {
  id: string;
  category: Category;
  title: string;
  description: string | null;
  price: string | null;
  image_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface SectionImage {
  id: string;
  category: Category;
  image_url: string;
  created_at: string;
}

export const CATEGORIES: { key: Category; label: string; description: string }[] = [
  { key: 'shoes', label: 'Shoes', description: 'Step into elegance with our curated footwear collection.' },
  { key: 'tshirts', label: 'T-Shirts', description: 'Refined essentials for the modern wardrobe.' },
  { key: 'pants', label: 'Pants', description: 'Tailored comfort meets timeless style.' },
  { key: 'other', label: 'Other Products', description: 'Discover unique pieces that complete your look.' },
];

const sanitizeFileName = (fileName: string) =>
  fileName
    .toLowerCase()
    .replace(/[^a-z0-9.]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');

export async function uploadStoreImage(file: File, folder: 'products' | 'sections') {
  const extension = file.name.split('.').pop()?.toLowerCase() || 'jpg';
  const safeName = sanitizeFileName(file.name.replace(/\.[^.]+$/, '')) || 'image';
  const filePath = `${folder}/${Date.now()}-${crypto.randomUUID()}-${safeName}.${extension}`;

  const { error } = await supabase.storage
    .from(PRODUCT_IMAGES_BUCKET)
    .upload(filePath, file, {
      cacheControl: '3600',
      upsert: false,
    });

  if (error) {
    throw error;
  }

  const { data } = supabase.storage.from(PRODUCT_IMAGES_BUCKET).getPublicUrl(filePath);
  return data.publicUrl;
}

async function compressImageToDataUrl(file: File) {
  const objectUrl = URL.createObjectURL(file);

  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('Unable to read the selected image.'));
      img.src = objectUrl;
    });

    const maxDimension = 1600;
    const scale = Math.min(1, maxDimension / Math.max(image.width, image.height));
    const width = Math.max(1, Math.round(image.width * scale));
    const height = Math.max(1, Math.round(image.height * scale));

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;

    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Unable to process the selected image.');
    }

    context.fillStyle = '#f5f5f4';
    context.fillRect(0, 0, width, height);
    context.drawImage(image, 0, 0, width, height);

    return canvas.toDataURL('image/jpeg', 0.82);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

export async function saveStoreImage(file: File, folder: 'products' | 'sections') {
  try {
    return await uploadStoreImage(file, folder);
  } catch (error) {
    console.warn(`Storage upload failed for ${folder}; falling back to inline image.`, error);
    return compressImageToDataUrl(file);
  }
}

export function getStoragePathFromUrl(publicUrl: string | null | undefined) {
  if (!publicUrl) return null;

  try {
    const url = new URL(publicUrl);
    const marker = `/storage/v1/object/public/${PRODUCT_IMAGES_BUCKET}/`;
    const pathIndex = url.pathname.indexOf(marker);

    if (pathIndex === -1) return null;

    return decodeURIComponent(url.pathname.slice(pathIndex + marker.length));
  } catch {
    return null;
  }
}

export async function removeStoreImage(publicUrl: string | null | undefined) {
  const storagePath = getStoragePathFromUrl(publicUrl);
  if (!storagePath) return;

  await supabase.storage.from(PRODUCT_IMAGES_BUCKET).remove([storagePath]);
}
