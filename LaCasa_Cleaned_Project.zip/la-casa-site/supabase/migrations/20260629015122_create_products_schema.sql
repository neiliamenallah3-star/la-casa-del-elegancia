/*
# Create products table for La Casa del Elegancia clothing store

1. New Tables
- `products`
  - `id` (uuid, primary key)
  - `category` (text, not null) - one of: 'shoes', 'tshirts', 'pants', 'other'
  - `title` (text, not null) - product name
  - `description` (text) - product description
  - `price` (text) - product price (text to allow flexible formatting)
  - `image_url` (text) - URL of product image
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)
- `section_images`
  - `id` (uuid, primary key)
  - `category` (text, not null) - one of: 'shoes', 'tshirts', 'pants', 'other'
  - `image_url` (text, not null) - cover image for the section
  - `created_at` (timestamptz)

2. Security
- Enable RLS on both tables.
- products: public read (anon + authenticated), only authenticated owner can write.
- section_images: public read, only authenticated owner can write.
- Owner is determined by auth.uid() - the store owner logs in via Supabase auth.

3. Notes
- The store owner has a private login. Public visitors can browse (read) all products
  and section images. Only the authenticated owner can add/edit/delete products and
  change section cover images.
*/

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL CHECK (category IN ('shoes', 'tshirts', 'pants', 'other')),
  title text NOT NULL,
  description text,
  price text,
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS section_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL CHECK (category IN ('shoes', 'tshirts', 'pants', 'other')),
  image_url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE section_images ENABLE ROW LEVEL SECURITY;

-- products: public read
DROP POLICY IF EXISTS "public_read_products" ON products;
CREATE POLICY "public_read_products" ON products FOR SELECT
  TO anon, authenticated USING (true);

-- products: authenticated owner can insert
DROP POLICY IF EXISTS "owner_insert_products" ON products;
CREATE POLICY "owner_insert_products" ON products FOR INSERT
  TO authenticated WITH CHECK (true);

-- products: authenticated owner can update
DROP POLICY IF EXISTS "owner_update_products" ON products;
CREATE POLICY "owner_update_products" ON products FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- products: authenticated owner can delete
DROP POLICY IF EXISTS "owner_delete_products" ON products;
CREATE POLICY "owner_delete_products" ON products FOR DELETE
  TO authenticated USING (true);

-- section_images: public read
DROP POLICY IF EXISTS "public_read_section_images" ON section_images;
CREATE POLICY "public_read_section_images" ON section_images FOR SELECT
  TO anon, authenticated USING (true);

-- section_images: authenticated owner can insert
DROP POLICY IF EXISTS "owner_insert_section_images" ON section_images;
CREATE POLICY "owner_insert_section_images" ON section_images FOR INSERT
  TO authenticated WITH CHECK (true);

-- section_images: authenticated owner can update
DROP POLICY IF EXISTS "owner_update_section_images" ON section_images;
CREATE POLICY "owner_update_section_images" ON section_images FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- section_images: authenticated owner can delete
DROP POLICY IF EXISTS "owner_delete_section_images" ON section_images;
CREATE POLICY "owner_delete_section_images" ON section_images FOR DELETE
  TO authenticated USING (true);

-- Index for category lookups
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_section_images_category ON section_images(category);
